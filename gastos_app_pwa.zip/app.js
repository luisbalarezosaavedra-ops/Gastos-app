const root = document.getElementById("root");
root.innerHTML = "<h1>Gastos App PWA</h1><p>App lista para organizar tus gastos.</p>";